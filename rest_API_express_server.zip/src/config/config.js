require('dotenv').config();

module.exports = {
  serverPort: process.env.SERVER_PORT,
};
