# buy-alot-of-food-backend

Web API made with Node and Express.

To start, run 

`npm start`

To start in dev environment, run 

`npm run dev`